#include "widget.h"
#include "ui_widget.h"
#include <QPixmap>
#include <QImage>
#include <QTimer>
#include <QDebug>

int i = 0;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->timer = new QTimer;

    connect(this->timer, SIGNAL(timeout()), this, SLOT(update_pic()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_start_clicked()
{
    timer->start(1000);
}

void Widget::on_pushButton_stop_clicked()
{
    timer->stop();
}

void Widget::update_pic()
{
    char buf[100] = {0};
    if(i >= 10)
    {
        i=0;
    }
    sprintf(buf,"/home/farsight/bwl/day10/time_pic/pic/%d.jpg",i);
    i++;
    qDebug() << buf;
    QImage *img = new QImage(buf);
    ui->label->setPixmap(QPixmap::fromImage(*img));
}
